# AlphaDSSP
 DSSP Analysis for Alphafold Secondary Structure Parsing
